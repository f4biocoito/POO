#ifndef __SIMULACAO_H__
#define __SIMULACAO_H__

#include <string>
#include <iostream>

using namespace std;




#endif

//COMANDOS
//foco linha coluna
//zoomout n (opcional + 5%)
//setmoedas colonia num
//build edif lin col
//list colonia
//list perfil
//listallp
//mkbuild edif lin col colonia
//repair EID
//upgrade EID
//sell EID
//ser num perf
//next
//next num
//ataca
//recolhe
//fim
//save nome
//restore nome
//erase nome
//load ficheiro