#ifndef __ATAQUES_H__
#define __ATAQUES_H__

#include <string>
#include <iostream>

using namespace std;




#endif