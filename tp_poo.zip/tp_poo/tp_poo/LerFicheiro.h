#ifndef __LERFICHEIRO_H__
#define __LERFICHEIRO_H__

#include "Consola.h"
#include <fstream>
#include <string>
#include <sstream>
#include <iostream>

using namespace std;




#endif