#ifndef __CONFIGURACAO_H__
#define __CONFIGURACAO_H__

#include <string>
#include <iostream>

using namespace std;

class Configuracao
{
public:
	Configuracao();
	~Configuracao();

};


#endif

//COMANDOS
//dim linhas colunas
//moedas numero
//oponentes numero
//castelo colonia lin col
//mkperfil letra
//addperfil letra caracteristica
//subperfil letra caracteristica
//reperfil letra
//load ficeiro
//inicio