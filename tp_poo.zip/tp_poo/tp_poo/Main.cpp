#include <string>
#include <iostream>
using namespace std;

#include "Load.h"


int main() {

	cout << "ola e adeus" << endl;
	return 0;
}