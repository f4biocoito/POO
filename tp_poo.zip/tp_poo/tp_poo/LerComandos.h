#ifndef __LERCOMANDOS_H__
#define __LERCOMANDOS_H__

#include <string>
#include <iostream>

using namespace std;




#endif