#ifndef __DEFINES_H__
#define __DEFINES_H__

#include <string>
#include <iostream>
#include "Load.h"

using namespace std;

#define ALTURA 20
#define LARGURA 40


#endif