#ifndef __INTERACAO_H__
#define __INTERACAO_H__

#include <string>
#include <iostream>
#include "Load.h"

class Interacao {
	
public:
	Interacao();
	int menu();
	void corre();
};

#endif