
#include"Configuracao.h"

class Configuracao
{
public:
	Configuracao();
	~Configuracao();

private:

};

Configuracao::Configuracao()
{
}

Configuracao::~Configuracao()
{
}
